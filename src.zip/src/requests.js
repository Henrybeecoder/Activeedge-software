
const requests = {
users: `/users`,
albums: `/albums`,
albumPhotos: `/albums/{album-id}/photos`,
comments: `/comments`,
commentPost: `/comments`,
tweet: `/comments/{comment-id}`,

}
export default requests;